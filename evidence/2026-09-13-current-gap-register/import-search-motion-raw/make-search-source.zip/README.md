
  # 书籍搜索页设计

  This is a code bundle for 书籍搜索页设计. The original project is available at https://www.figma.com/design/SW2sjgSEPEPuPwyR0TULyP/%E4%B9%A6%E7%B1%8D%E6%90%9C%E7%B4%A2%E9%A1%B5%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  