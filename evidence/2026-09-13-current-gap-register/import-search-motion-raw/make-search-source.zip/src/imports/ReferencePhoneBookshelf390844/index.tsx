import svgPaths from "./svg-o1hnootjs1";
import imgImage from "./e37bad3082ea62920cbd047fe9a194643c93987c.png";
import imgImage1 from "./68b69f621b723d75a2269f69ef426cf95161ffcc.png";
import imgImage2 from "./ae93593311f25c197eb69278f53c307533e02b2a.png";
import imgImage3 from "./a6dd26a470f0140e7427a626fb9a0783fba2b6f9.png";
import imgImage4 from "./6479ee1e12dbb8f8cd9043fab29c3e34330412cd.png";
import imgImageAndroid from "./977354b17329106dceb220ee0d227ebac3da4274.png";

function Text() {
  return (
    <div className="relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic relative shrink-0 text-[#1f1b17] text-[14px] whitespace-nowrap">10:30</p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[11.997px] relative shrink-0 w-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 11.9965">
        <g id="Icon">
          <path d={svgPaths.p177483e0} fill="var(--fill-0, #1F1B17)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[11.997px] relative shrink-0 w-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 11.9965">
        <g id="Icon">
          <path d={svgPaths.p3c3842e0} id="Vector" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.249927" />
          <path d={svgPaths.p254a1780} id="Vector_2" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.249927" />
          <path d={svgPaths.p342f1a80} id="Vector_3" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.249927" />
          <path d={svgPaths.pe696940} fill="var(--fill-0, #1F1B17)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[13.993px] relative shrink-0 w-[11.997px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 13.9931">
        <g id="Icon">
          <path d={svgPaths.p19c8aff0} id="Vector" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.249927" />
          <path d="M4.99854 1.99801H6.99796" id="Vector_2" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.249927" />
          <path d={svgPaths.p29b9a280} id="Vector_3" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.249927" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic relative shrink-0 text-[#1f1b17] text-[14px] whitespace-nowrap">82%</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[5px] items-center relative size-full">
        <Icon />
        <Icon1 />
        <Icon2 />
        <Text2 />
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="h-[47.995px] relative shrink-0 w-full" data-name="Header - 系统状态栏">
      <div className="flex flex-row items-end size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-end justify-between pb-[9px] px-[23px] relative size-full">
          <Text />
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[40.556px] relative shrink-0 w-[57.995px]" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#1f1b17] text-[29px] whitespace-nowrap">书架</p>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="absolute left-[10px] size-[23.993px] top-[10px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.9931 23.9931">
        <g id="Icon">
          <path d={svgPaths.p27316c80} id="Vector" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.499856" />
          <path d={svgPaths.p22ab500} id="Vector_2" stroke="var(--stroke-0, #1F1B17)" strokeWidth="0.499856" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="relative rounded-[21.997px] shrink-0 size-[43.993px]" data-name="Button - 搜索">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[10px] size-[23.993px] top-[10px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.9931 23.9931">
        <g id="Icon">
          <path d={svgPaths.p333aaa00} fill="var(--fill-0, #1F1B17)" id="Vector" />
          <path d={svgPaths.p26460d80} fill="var(--fill-0, #1F1B17)" id="Vector_2" />
          <path d={svgPaths.p5e51a80} fill="var(--fill-0, #1F1B17)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="relative rounded-[21.997px] shrink-0 size-[43.993px]" data-name="Button - 更多">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[18px] items-center relative size-full">
        <Button />
        <Button1 />
      </div>
    </div>
  );
}

function Section() {
  return (
    <div className="h-[58px] min-h-[58px] relative shrink-0 w-full" data-name="Section - 顶部栏">
      <div className="flex flex-row items-center min-h-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between min-h-[inherit] pt-[6px] px-[20px] relative size-full">
          <Heading />
          <Container />
        </div>
      </div>
    </div>
  );
}

function PlaceholderForContainer() {
  return <div className="h-[736.875px] relative shrink-0 w-full" data-name="Placeholder for Container" />;
}

function Paragraph() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-0 top-[-4px] w-[388.889px]" data-name="Paragraph">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.8px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">当前 Tab：书架 · 视图：封面</p>
    </div>
  );
}

function ParagraphMargin() {
  return (
    <div className="h-[13px] relative shrink-0 w-full" data-name="Paragraph:margin">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Paragraph />
      </div>
    </div>
  );
}

function Image() {
  return (
    <div className="absolute h-[92.995px] left-0 rounded-[6px] top-0 w-[61.997px]" data-name="Image (长夜余火封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[6px] size-full" src={imgImage} />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute h-[92.995px] left-[16px] overflow-clip rounded-[6px] top-[2.95px] w-[61.997px]" data-name="Button - 打开 长夜余火">
      <Image />
    </div>
  );
}

function Heading1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['Inter:Black','Noto_Sans_SC:Black',sans-serif] font-black leading-[15.6px] not-italic relative shrink-0 text-[#2d4a3e] text-[13px] whitespace-nowrap">继续阅读</p>
      </div>
    </div>
  );
}

function BoldText() {
  return (
    <div className="content-stretch flex flex-col h-[23.993px] items-start overflow-clip relative shrink-0 w-full" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[24px] not-italic relative shrink-0 text-[#1f1b17] text-[20px] whitespace-nowrap">长夜余火</p>
    </div>
  );
}

function BoldTextMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Bold Text:margin">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[6px] relative size-full">
        <BoldText />
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="content-stretch flex flex-col h-[16.797px] items-start overflow-clip relative shrink-0 w-full" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.8px] not-italic relative shrink-0 text-[#756f69] text-[14px] whitespace-nowrap">爱潜水的乌贼</p>
    </div>
  );
}

function TextMargin() {
  return (
    <div className="relative shrink-0 w-full" data-name="Text:margin">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[5px] relative size-full">
        <Text3 />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute content-stretch flex flex-col h-[67.387px] items-start left-[91.99px] top-[15.75px] w-[145.816px]" data-name="Container">
      <Heading1 />
      <BoldTextMargin />
      <TextMargin />
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#2d4a3e] content-stretch flex flex-col h-[40px] items-center justify-center left-[251.8px] min-h-[40px] min-w-[74px] px-[14px] rounded-[999px] top-[29.44px] w-[81.997px]" data-name="Button">
      <p className="[word-break:break-word] font-['Inter:Extra_Bold','Noto_Sans_SC:Black',sans-serif] font-extrabold leading-[normal] not-italic relative shrink-0 text-[#fffaf4] text-[13px] text-center whitespace-nowrap">阅读</p>
    </div>
  );
}

function Section1() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] border-[#c1c7cd] border-[0.556px] border-solid h-[100px] left-[18.99px] rounded-[8px] top-[7.99px] w-[350.903px]" data-name="Section">
      <Button2 />
      <Container2 />
      <Button3 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="relative shrink-0" data-name="Heading 2">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <p className="[word-break:break-word] font-['Inter:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[18px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">我的书架</p>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[7px] size-[20px] top-[7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p17279900} id="Vector" stroke="var(--stroke-0, #2D4A3E)" strokeWidth="0.416667" />
          <path d={svgPaths.pc114680} id="Vector_2" stroke="var(--stroke-0, #2D4A3E)" strokeWidth="0.416667" />
          <path d={svgPaths.p3c924880} id="Vector_3" stroke="var(--stroke-0, #2D4A3E)" strokeWidth="0.416667" />
          <path d={svgPaths.p2d519680} id="Vector_4" stroke="var(--stroke-0, #2D4A3E)" strokeWidth="0.416667" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="relative rounded-[16.997px] shrink-0 size-[33.993px]" data-name="Button - 封面视图">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon5 />
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[7px] size-[20px] top-[7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M7.08333 5H17.0833" id="Vector" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
          <path d="M7.08333 10H17.0833" id="Vector_2" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
          <path d="M7.08333 15H17.0833" id="Vector_3" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
          <path d={svgPaths.pdfa2d80} id="Vector_4" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="relative rounded-[16.997px] shrink-0 size-[33.993px]" data-name="Button - 列表视图">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon6 />
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-[7px] size-[20px] top-[7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p2fd55800} id="Vector" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
          <path d="M5.83333 7.5H14.1667" id="Vector_2" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="relative rounded-[16.997px] shrink-0 size-[33.993px]" data-name="Button - 书架筛选：全部，最近更新，全部">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon7 />
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[7px] size-[20px] top-[7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3936d230} id="Vector" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
          <path d="M12.9167 12.9167L17.5 17.5" id="Vector_2" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="relative rounded-[16.997px] shrink-0 size-[33.993px]" data-name="Button - 书架搜索">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon8 />
      </div>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-[7px] size-[20px] top-[7px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3e128d00} id="Vector" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
          <path d={svgPaths.p377e58f0} id="Vector_2" stroke="var(--stroke-0, #756F69)" strokeWidth="0.416667" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="relative rounded-[16.997px] shrink-0 size-[33.993px]" data-name="Button - 书架显示设置">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon9 />
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Button4 />
        <Button5 />
        <Button6 />
        <Button7 />
        <Button8 />
      </div>
    </div>
  );
}

function Section2() {
  return (
    <div className="absolute content-stretch flex h-[38px] items-center justify-between left-[18.99px] min-h-[38px] top-[115.99px] w-[350.903px]" data-name="Section">
      <Heading2 />
      <Text4 />
    </div>
  );
}

function Image1() {
  return (
    <div className="absolute h-[145.443px] left-0 top-0 w-[96.962px]" data-name="Image (长夜余火封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.443px] left-[18.99px] overflow-clip rounded-[8px] top-[163.98px] w-[96.962px]" data-name="Button - 打开 长夜余火">
      <Image1 />
    </div>
  );
}

function BoldText1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[18.99px] overflow-clip top-[315.43px] w-[96.962px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">长夜余火</p>
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[18.99px] overflow-clip top-[339.72px] w-[96.962px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">爱潜水的乌贼</p>
    </div>
  );
}

function Image2() {
  return (
    <div className="absolute h-[146.519px] left-0 top-0 w-[96.97px]" data-name="Image (诡秘之主封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[145.95px] overflow-clip rounded-[8px] top-[163.98px] w-[96.97px]" data-name="Button - 打开 诡秘之主">
      <Image2 />
    </div>
  );
}

function BoldText2() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[145.95px] overflow-clip top-[315.43px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">诡秘之主</p>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[145.95px] overflow-clip top-[339.73px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">爱潜水的乌贼</p>
    </div>
  );
}

function Image3() {
  return (
    <div className="absolute h-[146.519px] left-0 top-0 w-[96.97px]" data-name="Image (明朝那些事儿封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[272.93px] overflow-clip rounded-[8px] top-[163.98px] w-[96.97px]" data-name="Button - 打开 明朝那些事儿">
      <Image3 />
    </div>
  );
}

function BoldText3() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[272.93px] overflow-clip top-[315.43px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">明朝那些事儿</p>
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[272.93px] overflow-clip top-[339.73px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">当年明月</p>
    </div>
  );
}

function Image4() {
  return (
    <div className="absolute h-[145.703px] left-0 top-0 w-[96.962px]" data-name="Image (三体封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.443px] left-[18.99px] overflow-clip rounded-[8px] top-[370.72px] w-[96.962px]" data-name="Button - 打开 三体">
      <Image4 />
    </div>
  );
}

function BoldText4() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[18.99px] overflow-clip top-[522.16px] w-[96.962px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">三体</p>
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[18.99px] overflow-clip top-[546.46px] w-[96.962px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">刘慈欣</p>
    </div>
  );
}

function Image5() {
  return (
    <div className="absolute h-[145.451px] left-0 top-0 w-[96.97px]" data-name="Image (人间词话封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage4} />
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[145.95px] overflow-clip rounded-[8px] top-[370.72px] w-[96.97px]" data-name="Button - 打开 人间词话">
      <Image5 />
    </div>
  );
}

function BoldText5() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[145.95px] overflow-clip top-[522.17px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">人间词话</p>
    </div>
  );
}

function Text9() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[145.95px] overflow-clip top-[546.47px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">王国维</p>
    </div>
  );
}

function ImageAndroid() {
  return (
    <div className="absolute h-[145.72px] left-0 top-0 w-[96.97px]" data-name="Image (Android 开发笔记封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImageAndroid} />
    </div>
  );
}

function ButtonAndroid() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[272.93px] overflow-clip rounded-[8px] top-[370.72px] w-[96.97px]" data-name="Button - 打开 Android 开发笔记">
      <ImageAndroid />
    </div>
  );
}

function BoldText6() {
  return (
    <div className="absolute content-stretch flex flex-col h-[36.597px] items-start left-[272.93px] overflow-clip top-[522.17px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] w-[97px]">Android 开发笔记</p>
    </div>
  );
}

function Text10() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[272.93px] overflow-clip top-[564.77px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">本地文档</p>
    </div>
  );
}

function Image6() {
  return (
    <div className="absolute h-[145.443px] left-0 top-0 w-[96.962px]" data-name="Image (旧日回响封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
    </div>
  );
}

function Button14() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.443px] left-[18.99px] overflow-clip rounded-[8px] top-[595.76px] w-[96.962px]" data-name="Button - 打开 旧日回响">
      <Image6 />
    </div>
  );
}

function BoldText7() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[18.99px] overflow-clip top-[747.2px] w-[96.962px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">旧日回响</p>
    </div>
  );
}

function Text11() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[18.99px] overflow-clip top-[771.49px] w-[96.962px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">离线书库</p>
    </div>
  );
}

function Image7() {
  return (
    <div className="absolute h-[145.72px] left-0 top-0 w-[96.97px]" data-name="Image (群星之间封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
    </div>
  );
}

function Button15() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[145.95px] overflow-clip rounded-[8px] top-[595.76px] w-[96.97px]" data-name="Button - 打开 群星之间">
      <Image7 />
    </div>
  );
}

function BoldText8() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[145.95px] overflow-clip top-[747.2px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">群星之间</p>
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[145.95px] overflow-clip top-[771.5px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">本地导入</p>
    </div>
  );
}

function Image8() {
  return (
    <div className="absolute h-[146.519px] left-0 top-0 w-[96.97px]" data-name="Image (灯塔与雾封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
    </div>
  );
}

function Button16() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[272.93px] overflow-clip rounded-[8px] top-[595.76px] w-[96.97px]" data-name="Button - 打开 灯塔与雾">
      <Image8 />
    </div>
  );
}

function BoldText9() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[272.93px] overflow-clip top-[747.2px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">灯塔与雾</p>
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[272.93px] overflow-clip top-[771.5px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">书源同步</p>
    </div>
  );
}

function Image9() {
  return (
    <div className="absolute h-[146.502px] left-0 top-0 w-[96.962px]" data-name="Image (纸上城市封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
    </div>
  );
}

function Button17() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.443px] left-[18.99px] overflow-clip rounded-[8px] top-[802.49px] w-[96.962px]" data-name="Button - 打开 纸上城市">
      <Image9 />
    </div>
  );
}

function BoldText10() {
  return (
    <div className="absolute content-stretch flex flex-col h-[18.299px] items-start left-[18.99px] overflow-clip top-[953.93px] w-[96.962px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] whitespace-nowrap">纸上城市</p>
    </div>
  );
}

function Text14() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[18.99px] overflow-clip top-[978.23px] w-[96.962px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">默认分组</p>
    </div>
  );
}

function Image10() {
  return (
    <div className="absolute h-[145.451px] left-0 top-0 w-[96.97px]" data-name="Image (长标题测试：这本书的名字很长需要两行截断封面)">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage4} />
    </div>
  );
}

function Button18() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[145.451px] left-[145.95px] overflow-clip rounded-[8px] top-[802.49px] w-[96.97px]" data-name="Button - 打开 长标题测试：这本书的名字很长需要两行截断">
      <Image10 />
    </div>
  );
}

function BoldText11() {
  return (
    <div className="absolute content-stretch flex flex-col h-[36.597px] items-start left-[145.95px] overflow-clip top-[953.94px] w-[96.97px]" data-name="Bold Text">
      <p className="[word-break:break-word] font-['Songti_SC:Bold',sans-serif] leading-[18.3px] not-italic relative shrink-0 text-[#1f1b17] text-[15px] w-[97px]">长标题测试：这本书的名字很长需要两行截断</p>
    </div>
  );
}

function Text15() {
  return (
    <div className="absolute content-stretch flex flex-col h-[14.991px] items-start left-[145.95px] overflow-clip top-[996.54px] w-[96.97px]" data-name="Text">
      <p className="[word-break:break-word] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] not-italic relative shrink-0 text-[#756f69] text-[12px] whitespace-nowrap">排版样本</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute h-[736.875px] left-[0.56px] top-[106.55px] w-[388.889px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <Section1 />
        <Section2 />
        <Button9 />
        <BoldText1 />
        <Text5 />
        <Button10 />
        <BoldText2 />
        <Text6 />
        <Button11 />
        <BoldText3 />
        <Text7 />
        <Button12 />
        <BoldText4 />
        <Text8 />
        <Button13 />
        <BoldText5 />
        <Text9 />
        <ButtonAndroid />
        <BoldText6 />
        <Text10 />
        <Button14 />
        <BoldText7 />
        <Text11 />
        <Button15 />
        <BoldText8 />
        <Text12 />
        <Button16 />
        <BoldText9 />
        <Text13 />
        <Button17 />
        <BoldText10 />
        <Text14 />
        <Button18 />
        <BoldText11 />
        <Text15 />
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-[3px] size-[23.993px] top-[3px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.9931 23.9931">
        <g id="Icon">
          <path d="M3.99885 19.4944H19.9943" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="0.499856" />
          <path d={svgPaths.p672e000} id="Vector_2" stroke="var(--stroke-0, white)" strokeWidth="0.499856" />
          <path d={svgPaths.p13923d00} id="Vector_3" stroke="var(--stroke-0, white)" strokeWidth="0.499856" />
          <path d={svgPaths.p75d4200} id="Vector_4" stroke="var(--stroke-0, white)" strokeWidth="0.499856" />
          <path d={svgPaths.p17081180} id="Vector_5" stroke="var(--stroke-0, white)" strokeWidth="0.499856" />
        </g>
      </svg>
    </div>
  );
}

function Text16() {
  return (
    <div className="absolute left-[27.97px] rounded-[15px] size-[30px] top-0" data-name="Text">
      <Icon10 />
    </div>
  );
}

function Button19() {
  return (
    <div className="absolute bg-[#1f3528] h-[52.891px] left-[8.55px] overflow-clip rounded-[24px] top-[7.55px] w-[85.946px]" data-name="Button">
      <Text16 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Extra_Bold','Noto_Sans_JP:Black','Noto_Sans_SC:Black',sans-serif] font-extrabold leading-[18px] left-[42.47px] not-italic text-[#fffaf4] text-[11px] text-center top-[32.99px] whitespace-nowrap">书架</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute flex inset-[0.01%_0.01%_0.02%_-0.04%] items-center justify-center" style={{ containerType: "size" }}>
      <div className="-rotate-180 -scale-x-100 flex-none h-[100cqh] w-[100cqw]">
        <div className="relative size-full" data-name="Group">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.0003 23.9866">
            <g id="Group">
              <path d={svgPaths.p30eafa00} fill="var(--fill-0, #756F69)" id="Vector" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="absolute left-[3px] overflow-clip size-[23.993px] top-[3px]" data-name="Icon">
      <Group />
    </div>
  );
}

function Text17() {
  return (
    <div className="absolute left-[27.98px] rounded-[15px] size-[30px] top-0" data-name="Text">
      <Icon11 />
    </div>
  );
}

function Button20() {
  return (
    <div className="absolute h-[52.891px] left-[94.5px] overflow-clip rounded-[24px] top-[7.55px] w-[85.955px]" data-name="Button">
      <Text17 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Extra_Bold','Noto_Sans_SC:Black',sans-serif] font-extrabold leading-[18px] left-[42.98px] not-italic text-[#756f69] text-[11px] text-center top-[32.99px] whitespace-nowrap">发现</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute flex inset-[-0.02%_1.11%_-0.03%_1.1%] items-center justify-center" style={{ containerType: "size" }}>
      <div className="-rotate-180 -scale-x-100 flex-none h-[100cqh] w-[100cqw]">
        <div className="relative size-full" data-name="Group">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.4627 24.0051">
            <g id="Group">
              <path d={svgPaths.p579e600} fill="var(--fill-0, #756F69)" id="Vector" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon12() {
  return (
    <div className="absolute left-[3px] overflow-clip size-[23.993px] top-[3px]" data-name="Icon">
      <Group1 />
    </div>
  );
}

function Text18() {
  return (
    <div className="absolute left-[27.97px] rounded-[15px] size-[30px] top-0" data-name="Text">
      <Icon12 />
    </div>
  );
}

function Button21() {
  return (
    <div className="absolute h-[52.891px] left-[180.45px] overflow-clip rounded-[24px] top-[7.55px] w-[85.946px]" data-name="Button">
      <Text18 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Extra_Bold',sans-serif] font-extrabold leading-[18px] left-[42.97px] not-italic text-[#756f69] text-[11px] text-center top-[32.99px] whitespace-nowrap">RSS</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute flex inset-[0_0.33%_0_0.34%] items-center justify-center" style={{ containerType: "size" }}>
      <div className="-rotate-180 -scale-x-100 flex-none h-[100cqh] w-[100cqw]">
        <div className="relative size-full" data-name="Group">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.8307 23.9932">
            <g id="Group">
              <path d={svgPaths.p2bfb4440} fill="var(--fill-0, #756F69)" id="Vector" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="absolute left-[3px] overflow-clip size-[23.993px] top-[3px]" data-name="Icon">
      <Group2 />
    </div>
  );
}

function Text19() {
  return (
    <div className="absolute left-[27.98px] rounded-[15px] size-[30px] top-0" data-name="Text">
      <Icon13 />
    </div>
  );
}

function Button22() {
  return (
    <div className="absolute h-[52.891px] left-[266.4px] overflow-clip rounded-[24px] top-[7.55px] w-[85.955px]" data-name="Button">
      <Text19 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Extra_Bold','Noto_Sans_JP:Black','Noto_Sans_SC:Black',sans-serif] font-extrabold leading-[18px] left-[42.48px] not-italic text-[#756f69] text-[11px] text-center top-[32.99px] whitespace-nowrap">设置</p>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute bg-[rgba(255,252,248,0.9)] h-[68px] left-[14.55px] min-h-[68px] rounded-[24px] top-[761.45px] w-[360.903px]" data-name="Navigation - 公共主导航">
      <div aria-hidden className="absolute border-[#c1c7cd] border-[0.556px] border-solid inset-0 pointer-events-none rounded-[24px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button19 />
        <Button20 />
        <Button21 />
        <Button22 />
      </div>
    </div>
  );
}

export default function ReferencePhoneBookshelf() {
  return (
    <div className="bg-[#f8f4ec] relative rounded-[34px] size-full" data-name="Reference/Phone/bookshelf · 390×844">
      <div className="content-stretch flex flex-col items-start overflow-clip p-[0.556px] relative rounded-[inherit] size-full">
        <Header />
        <Section />
        <PlaceholderForContainer />
        <ParagraphMargin />
        <Container1 />
        <Navigation />
      </div>
      <div aria-hidden className="absolute border-[#c1c7cd] border-[0.556px] border-solid inset-0 pointer-events-none rounded-[34px]" />
    </div>
  );
}